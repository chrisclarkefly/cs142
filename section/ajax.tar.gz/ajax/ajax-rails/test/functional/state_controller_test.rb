require 'test_helper'

class StateControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end
