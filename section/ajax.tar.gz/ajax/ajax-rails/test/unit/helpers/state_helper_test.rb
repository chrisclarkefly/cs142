require 'test_helper'

class StateHelperTest < ActionView::TestCase
end
