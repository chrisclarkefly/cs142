# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
AjaxServer::Application.config.secret_token = '2477fb2ec83e31f17ac6db56606fab66af43d339e0b12a5acac5341951014bfeecd59ce29c8b9eb6ae4215ff1d77a2092542b23fb299d9865eed4fdeefe252a0'
