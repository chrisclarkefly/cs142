# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
Section::Application.config.secret_token = '155d94da19e7765936d33408c229ec15a1f78390ccc64bdcbdafebf9c58dded9a73cdc7b9958e7c7fb206abd941be04f90b509a0d18ada3ff94665173135a710'
