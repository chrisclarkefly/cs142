require 'test_helper'

class TranslateTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
