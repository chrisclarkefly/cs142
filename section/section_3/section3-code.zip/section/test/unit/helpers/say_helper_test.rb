require 'test_helper'

class SayHelperTest < ActionView::TestCase
end
