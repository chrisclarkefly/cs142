# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
Section5::Application.config.secret_token = 'e900f6928e8c3ac5a829745aef40927b820d4b911445be1e8f20de4fc01d5604e9c7171c42ceb84554f2c8e6dd03ac3db5dbc7c5e3be3ef5d17a0b962db99421'
