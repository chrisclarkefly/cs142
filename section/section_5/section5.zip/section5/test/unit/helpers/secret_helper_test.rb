require 'test_helper'

class SecretHelperTest < ActionView::TestCase
end
