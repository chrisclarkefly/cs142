require 'test_helper'

class PostHelperTest < ActionView::TestCase
end
