# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
P4demo::Application.config.secret_token = 'b017f61f2679bbaaf293fa6415f3095e32e225838496b1e635313fd8e3dca05e7bb61dcd9b48a600ea1078bce9c30cd025ce677e5046f211dd545280aef70238'
